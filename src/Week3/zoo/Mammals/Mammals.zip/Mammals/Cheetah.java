package Week3.zoo.Mammals;

public class Cheetah extends Mammals {

    public Cheetah(String name, String color, double size, boolean milk) {
        super(name, color, size, milk);



    }

    @Override
    public void growl() {System.out.println("Fast as barnacles boi!");}

}

