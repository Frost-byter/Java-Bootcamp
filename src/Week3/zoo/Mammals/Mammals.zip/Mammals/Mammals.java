package Week3.zoo.Mammals;

public class Mammals {
    public String name;
    String color;
    protected double size;
    public boolean milk;


    public Mammals(String name, String color, double size, boolean milk) {

        this.name = name;
        this.color = color;
        this.size = size;
        this.milk = milk;
    }

    public static void Mammals() {
    }

    public void growl() {

    }

    public void roar() {

    }

    public void Moo(){

    }
}
