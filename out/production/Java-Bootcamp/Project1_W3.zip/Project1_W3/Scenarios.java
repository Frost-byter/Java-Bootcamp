package Project1_W3;

import java.util.Scanner;

public class Scenarios extends Adventurers {
    Scanner in = new Scanner(System.in);

    public  Scenarios(){
        super();
        System.out.println("You find yourself waking up in a strange forest, the flora and fauna around" +
                " you is unrecognizable. You look around and notice that the trees are varying shades of green and brown" +
                " with many vines wrapping around them, and hanging down from the branches. You hear the cries of different animals" +
                " in the distance, each one sounds alien to you and unfamiliar. The only familiar thing the situation in which you find yourself is" +
                " is the slightly warm breeze blowing past you and ruffling your hair.");

        //insert line break here*

        System.out.println("As you acclimate to your new surroundings you meet some villagers while walking, they think you strange but offer to bring you back with them and offer food and water.");

        //either insert line break here or combine these two*

        System.out.println("One of the villagers offers you a room at his home, a burly gentleman with gnarled, rough hands. He stood a foot over you easily but he had a gentle smile with bronze skin and curly, lightly tousled hair." +
                "You graciously follow him to his abode. Once inside you come across a chest and your host Jako, explains that he used to be an adventurer." +
                " He says you're welcome to pick one sword out of his collection. You open it and inside sits three weapons, a bronze sword, a steel sword, and a black sword. Choose wisely, you may only take one young" +
                "adventurer: "  );



            System.out.println("\tChoose your Action: ");
            System.out.println("\t1. BronzeSword ");
            System.out.println("\t2. Steel Sword ");
            System.out.println("\t3. Silver Sword ");

        String input = in.nextLine();
        if (input.equalsIgnoreCase("1")) {
            int damageValue = advent.getAtt() + AttackItems.bronzeSword;
            System.out.println(advent.setAdventurers(name) + " has picked the BronzeSword, your attack is now: " + damageValue + " damage.");

        } else if (input.equalsIgnoreCase("2")){
            int damageValue = advent.getAtt() + AttackItems.steelSword;
            System.out.println(advent.setAdventurers(name) + " has picked the SteelSword, your attack is now: " + damageValue + " damage.");

        } else {input.equalsIgnoreCase("3");}

        // insert a line break here*
        System.out.println("You spend the next month slowly getting used to your new life and learning about your environment. Jako said that you are well suited to becoming an adventurer" +
                " but he warns that this occupation is exceptionally dangerous at times and so has been tutoring you in the way of the sword. You find that you surprisingly enjoy this." +
                "");

    }

}
