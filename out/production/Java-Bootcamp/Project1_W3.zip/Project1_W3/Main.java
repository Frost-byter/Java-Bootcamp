package Project1_W3;

import java.util.Scanner;
import java.util.Random;

import static Project1_W3.Adventurers.HP;

public class Main {

    Scenarios Scene = new Scenarios();


    public static void main(String[] args){

        //need to clean this up a bit

        Scanner in = new Scanner(System.in);
        System.out.println("The goddess smiles on thee. Pray tell, what if your name dear adventurer!: ");
//        String name = in.nextLine();
        Adventurers advent = new Adventurers();

        System.out.println(advent.getName());
        System.out.println("Weary " + advent.getName() + " Rest thy soul");

        advent.setHP(100);
        advent.setDef(15);
        advent.setAtt(10);



        AttackItems attackItems = new AttackItems(10, 20, 30);
        System.out.println(attackItems.toString(attackItems.getsteelSword(), advent.getAtt()));

        advent.setWeaponValue(attackItems.getsteelSword());// for automation of attack values when picking weapons throughout story. Have to write out logic for all 3 items
        System.out.println(advent.getAtt());

        DefItems DefenseItems = new DefItems(15, 25, 40);
        System.out.println(DefenseItems.toString(DefenseItems.getblackArmor(), advent.getDef()));

        UtilItems Necklaces = new UtilItems(15, 10, 12);
        System.out.println(Necklaces.toString(Necklaces.getnecklaceofAgaroth(), advent.getHP(),advent.getDef(), advent.getAtt()));

        advent.setAtt(advent.getAtt() + Necklaces.getnecklaceofAgaroth());
        System.out.println(advent.getAtt());


        //Combat stats for monsters
        Monsters Combat = new Monsters();
        System.out.println(Combat.getmaxHealth());
        System.out.println(Combat.getmaxAtt());
        System.out.println(Combat.getmaxDef());


        boolean running = true;
        //Need intro around here


            Object Game;
            while(running) {//combat mechanics between user and monsters
             System.out.println("--------------------------------------------");

                Random rand = new Random();//creating a random constructor to call a random monster
                String String[] = new String[]{String[rand.nextInt(String.length)]};
                System.out.println("\t#" + String + " appeared as you make your way through the forest#\n");

                while (Combat.maxHealth > 0) {
                    System.out.println("\tAdventurer HP: " + HP);
                    System.out.println("\tEnemy HP: " + Combat.getmaxHealth());
                    System.out.println("\tChoose your Action: ");
                    System.out.println("\t1. Attack ");
                    System.out.println("\t2. Defend ");
                    System.out.println("\t3. Run ");

                    String input = in.nextLine();
                    if(input.equals("1")){
                        int damageDealt = advent.getAtt();
                        System.out.println("You attacked the" + String + "for: " + damageDealt + " damage");
                        //trying to set the amount of damage dealt to monster during combat + items and gear

                        int damageTaken = Combat.getmaxAtt() - advent.getDef() - advent.getHP();//+ DefItems()); //figure this out, don't forget parenthesis
                        System.out.println("The " + String + "attacked you for: " + damageTaken + " damage");
                        System.out.println("Your HP is now: " + advent.getHP());

                         int enemyHealth = Combat.getmaxHealth() - damageDealt;
                        System.out.println("The " + String + "has: " + enemyHealth + " HP");

                            if(advent.getHP() < 0){
                                System.out.println("You have died dear adventurer, the goddess embraces thee");
                                break;
                            }
                    } else if(input.equals("2")){

                        int defend = Combat.getmaxAtt() - (2 * advent.getDef()) - advent.getHP();

                        System.out.println("You defended against " + String + "'s attack for: " + defend + " defense points");

                    }else if(input.equals("3")){

                        System.out.println(String + "'s ferocious visage has rendered you deathly afraid. With a sour smell running down your legs you turn tail and run");
//                        continue Game; // supposed to rerun the game simulation
                    } //else ()
                }
        }



    }

}
