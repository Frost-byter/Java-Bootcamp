package Project1_W3;

public class Archer extends Adventurers {

    public Archer(String name, int HP, int Att, int Def, int Xp, int lvl) {

        super();
    }
}
