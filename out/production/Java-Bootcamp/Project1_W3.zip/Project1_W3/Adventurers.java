package Project1_W3;


import java.util.Scanner;

public class Adventurers {

    protected String name;
    protected static int HP ;
    protected static int Att;
    protected static int Def;
    protected static int Xp;
    protected static int lvl;

    protected int weaponValue;
    protected int armorValue;
    protected int utilValue;

     Adventurers advent = new Adventurers();

     Scanner in = new Scanner(System.in);


    public Adventurers(){

        this.name = in.nextLine() ;
        this.HP = 100;
        this.Att = 10;
        this.Def = 15;
        this.Xp = 0;
        this.lvl = 1;
        this.weaponValue = 10;
        this.armorValue = 15;
        this.utilValue = 10;
    }


    public String getAdventurers(){return this.name;}

    public String setAdventurers(String name){
        this.name = name;
        return name;
    }

    public int getHP(){
        return this.HP + utilValue;
    }

    public void setHP(int Hp){
        this.HP = Hp;
    }

    public int getAtt(){
        return this.Att + this.weaponValue + utilValue;
    }

    public void setAtt(int Attack){
        this.Att = Attack;
    }

    public int getDef(){
        return this.Def + this.armorValue + utilValue;
    }

    public void setDef(int Defense){
        this.Def = Defense;
    }

    public String getName(){
        return this.name;
    }

    public int getXp(){
        return this.Xp;
    }

    public void setXp(int Experience){
        this.Xp = Experience;
    }

    public int getlvl(){
        return this.lvl;
    }

    public void setlvl(int Level){
        this.lvl = Level;
    }

    public int getWeaponValue(){return this.weaponValue;}

    public int getArmorValue() {
        return armorValue;
    }

    public int getUtilValue() {
        return utilValue;
    }

    public void setWeaponValue(int weaponValue){
        this.weaponValue = weaponValue;
    }
    public void setArmorValue(int armorValue){
        this.armorValue = armorValue;
    }

    public void setUtilValue(int utilValue) {
        this.utilValue = utilValue;
    }

    public void checkXp(){
        if (this.Xp == 100) {
            setlvl(this.lvl+1);
            this.Xp = 0;
        }
    }

//    public String toString(int HP,int Def, int Att) {
//
//        if (necklaceofGrowth == Items) {
//            HP += Items();
//            return "Your Health is now " + HP;
//        } else if (necklaceofTheSteadfast == Items){
//            Def += Items();
//            return "Your Defense is now " + Def;
//        } else{
//          Att += Items();
//           return "Your Attack is now " + Att;
//       }

    //}


}
