package Project1_W3;

public class Warrior extends Adventurers{
    //this.name = name;
//        this.HP = 100;
//        this.Att = 10;
//        this.Def = 15;
//        this.Xp = 0;
//        this.lvl = 1;
    public Warrior(String name, int HP, int Att, int Def, int Xp, int lvl ){

        super();
    }


}
