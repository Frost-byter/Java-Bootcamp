package Project1_W3;

public class Rogue extends Adventurers {


    public Rogue(String name, int Hp, int Att, int Def, int Xp, int lvl) {



        super();
    }
}
